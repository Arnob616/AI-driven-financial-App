"use client"

import Link from "next/link"
import { UserNav } from "@/components/layout/user-nav"
import { ThemeToggle } from "@/components/theme-toggle"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

export function MainNav() {
  return (
    <div className="flex h-16 items-center px-4 border-b">
      <div className="ml-auto flex items-center space-x-4">
        <Button size="sm" className="rounded-full">
          <Plus className="h-4 w-4 mr-1" />
          Add Transaction
        </Button>
        <ThemeToggle />
        <UserNav />
      </div>
    </div>
  )
}