'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Avatar } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowUpRight, 
  ArrowDownLeft,
  ArrowLeftRight, 
  Coffee, 
  ShoppingCart, 
  Home, 
  Car, 
  Utensils 
} from 'lucide-react';

const mockTransactions = [
  {
    id: '1',
    description: 'Starbucks',
    amount: 5.75,
    type: 'EXPENSE',
    category: 'Food',
    date: '2025-01-15T09:24:00',
    icon: <Coffee className="h-4 w-4" />,
    accountName: 'Chase Checking',
  },
  {
    id: '2',
    description: 'Amazon',
    amount: 49.99,
    type: 'EXPENSE',
    category: 'Shopping',
    date: '2025-01-14T17:31:00',
    icon: <ShoppingCart className="h-4 w-4" />,
    accountName: 'Chase Credit Card',
  },
  {
    id: '3',
    description: 'Rent Payment',
    amount: 1200.00,
    type: 'EXPENSE',
    category: 'Housing',
    date: '2025-01-10T08:00:00',
    icon: <Home className="h-4 w-4" />,
    accountName: 'Chase Checking',
  },
  {
    id: '4',
    description: 'Paycheck',
    amount: 2100.00,
    type: 'INCOME',
    category: 'Salary',
    date: '2025-01-05T09:00:00',
    icon: <ArrowUpRight className="h-4 w-4" />,
    accountName: 'Chase Checking',
  },
  {
    id: '5',
    description: 'Uber',
    amount: 22.50,
    type: 'EXPENSE',
    category: 'Transportation',
    date: '2025-01-04T19:24:00',
    icon: <Car className="h-4 w-4" />,
    accountName: 'Amex Credit Card',
  },
  {
    id: '6',
    description: 'Chipotle',
    amount: 15.25,
    type: 'EXPENSE',
    category: 'Food',
    date: '2025-01-02T12:30:00',
    icon: <Utensils className="h-4 w-4" />,
    accountName: 'Chase Credit Card',
  },
];

export function RecentTransactions() {
  const [filter, setFilter] = useState('all');
  
  const filteredTransactions = filter === 'all' 
    ? mockTransactions 
    : mockTransactions.filter(t => t.type === filter.toUpperCase());
  
  return (
    <Card className="col-span-4">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="space-y-0.5">
          <CardTitle>Recent Transactions</CardTitle>
          <CardDescription>
            Your most recent financial activities
          </CardDescription>
        </div>
        <Select defaultValue={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-[140px] h-8">
            <SelectValue placeholder="Filter" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Transactions</SelectItem>
            <SelectItem value="income">Income Only</SelectItem>
            <SelectItem value="expense">Expenses Only</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {filteredTransactions.map(transaction => (
            <div key={transaction.id} className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className={`flex h-9 w-9 items-center justify-center rounded-full ${
                  transaction.type === 'INCOME' 
                    ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300'
                    : 'bg-rose-100 text-rose-700 dark:bg-rose-900 dark:text-rose-300'
                }`}>
                  {transaction.type === 'INCOME' 
                    ? <ArrowUpRight className="h-4 w-4" />
                    : <ArrowDownLeft className="h-4 w-4" />
                  }
                </div>
                <div>
                  <p className="text-sm font-medium">{transaction.description}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(transaction.date).toLocaleDateString()} • {transaction.accountName}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <Badge variant="outline" className="text-xs">
                  {transaction.category}
                </Badge>
                <span className={`text-sm font-medium ${
                  transaction.type === 'INCOME' 
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-rose-600 dark:text-rose-400'
                }`}>
                  {transaction.type === 'INCOME' ? '+' : '-'}${transaction.amount.toFixed(2)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}