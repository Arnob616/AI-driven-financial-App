'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { PlusIcon } from 'lucide-react';

const mockBudgetData = [
  {
    category: 'Housing',
    allocated: 1200,
    spent: 1150,
    color: 'bg-red-500',
  },
  {
    category: 'Food & Dining',
    allocated: 600,
    spent: 480,
    color: 'bg-blue-500',
  },
  {
    category: 'Transportation',
    allocated: 300,
    spent: 275,
    color: 'bg-green-500',
  },
  {
    category: 'Entertainment',
    allocated: 200,
    spent: 230,
    color: 'bg-yellow-500',
  },
  {
    category: 'Shopping',
    allocated: 300,
    spent: 210,
    color: 'bg-purple-500',
  },
];

export function BudgetProgress() {
  return (
    <Card className="col-span-3">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="space-y-0.5">
          <CardTitle>Budget Progress</CardTitle>
          <CardDescription>
            Your monthly budget allocation and spending
          </CardDescription>
        </div>
        <Button size="sm" variant="outline">
          <PlusIcon className="h-4 w-4 mr-2" />
          New Budget
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {mockBudgetData.map((budget, index) => {
            const percentUsed = Math.round((budget.spent / budget.allocated) * 100);
            const isOverBudget = budget.spent > budget.allocated;
            
            return (
              <div key={index} className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{budget.category}</span>
                  <span className="text-sm text-muted-foreground">
                    ${budget.spent.toLocaleString()} / ${budget.allocated.toLocaleString()}
                  </span>
                </div>
                <Progress
                  value={percentUsed > 100 ? 100 : percentUsed}
                  className={`h-2 ${isOverBudget ? 'bg-muted-foreground/20' : ''}`}
                  indicatorClassName={isOverBudget ? 'bg-destructive' : undefined}
                />
                {isOverBudget && (
                  <p className="text-xs text-destructive">
                    Over budget by ${(budget.spent - budget.allocated).toFixed(2)}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}