'use client';

import { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid,
  LineChart,
  Line 
} from 'recharts';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const mockMonthlyData = [
  { name: 'Jan', income: 4100, expenses: 2400 },
  { name: 'Feb', income: 3800, expenses: 2200 },
  { name: 'Mar', income: 4200, expenses: 2600 },
  { name: 'Apr', income: 4100, expenses: 2350 },
  { name: 'May', income: 4300, expenses: 2800 },
  { name: 'Jun', income: 4500, expenses: 2950 },
  { name: 'Jul', income: 4200, expenses: 2700 },
  { name: 'Aug', income: 4600, expenses: 2850 },
  { name: 'Sep', income: 4700, expenses: 2900 },
  { name: 'Oct', income: 4800, expenses: 3000 },
  { name: 'Nov', income: 4900, expenses: 3100 },
  { name: 'Dec', income: 5000, expenses: 2950 },
];

const mockCategoryData = [
  { name: 'Housing', value: 1200 },
  { name: 'Food', value: 500 },
  { name: 'Transport', value: 300 },
  { name: 'Utilities', value: 250 },
  { name: 'Entertainment', value: 200 },
  { name: 'Shopping', value: 350 },
  { name: 'Health', value: 150 },
];

export function ExpensesChart() {
  const [period, setPeriod] = useState("year");
  const [chartType, setChartType] = useState("overview");
  
  return (
    <Card className="col-span-4">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="space-y-0.5">
          <CardTitle>Financial Overview</CardTitle>
          <CardDescription>
            Monitor your income and expenses
          </CardDescription>
        </div>
        <div className="flex items-center gap-2">
          <Tabs defaultValue="overview" className="w-[200px]" onValueChange={(value) => setChartType(value)}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="category">By Category</TabsTrigger>
            </TabsList>
          </Tabs>
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[120px] h-8">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
              <SelectItem value="year">This Year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] w-full">
          {chartType === "overview" ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart 
                data={mockMonthlyData}
                margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
              >
                <defs>
                  <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorExpenses" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--chart-2))" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="hsl(var(--chart-2))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="name" 
                  className="text-xs" 
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                />
                <YAxis 
                  className="text-xs" 
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  tickFormatter={(value) => `$${value}`}
                />
                <Tooltip 
                  formatter={(value) => [`$${value}`, undefined]}
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--background))', 
                    border: '1px solid hsl(var(--border))' 
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="income" 
                  name="Income"
                  stroke="hsl(var(--chart-1))" 
                  strokeWidth={2}
                  activeDot={{ r: 8 }}
                  fillOpacity={0.3}
                  fill="url(#colorIncome)"
                />
                <Line 
                  type="monotone" 
                  dataKey="expenses" 
                  name="Expenses"
                  stroke="hsl(var(--chart-2))" 
                  strokeWidth={2}
                  fillOpacity={0.3}
                  fill="url(#colorExpenses)"
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={mockCategoryData}
                margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="name" 
                  className="text-xs" 
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                />
                <YAxis 
                  className="text-xs" 
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  tickFormatter={(value) => `$${value}`}
                />
                <Tooltip 
                  formatter={(value) => [`$${value}`, undefined]}
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--background))', 
                    border: '1px solid hsl(var(--border))' 
                  }}
                />
                <Bar 
                  dataKey="value" 
                  name="Amount"
                  fill="hsl(var(--chart-2))"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </CardContent>
    </Card>
  );
}