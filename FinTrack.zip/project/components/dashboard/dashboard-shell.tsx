export function DashboardShell({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex-1 items-start md:grid md:gap-8 md:grid-cols-[240px_minmax(0,1fr)] lg:grid-cols-[280px_minmax(0,1fr)]">
      <main className="flex w-full flex-col overflow-hidden">
        <div className="container flex-1 items-start pb-8 pt-6 md:py-8">
          <div className="mx-auto w-full max-w-7xl space-y-6">{children}</div>
        </div>
      </main>
    </div>
  );
}