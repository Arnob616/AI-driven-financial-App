'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { Button } from '@/components/ui/button';
import { PlusIcon } from 'lucide-react';

const mockAccountsData = [
  { name: 'Checking', value: 8540.23, color: 'hsl(var(--chart-1))' },
  { name: 'Savings', value: 12750.00, color: 'hsl(var(--chart-2))' },
  { name: 'Investment', value: 3290.30, color: 'hsl(var(--chart-3))' },
];

const totalBalance = mockAccountsData.reduce((sum, account) => sum + account.value, 0);

export function AccountsOverview() {
  return (
    <Card className="col-span-3">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="space-y-0.5">
          <CardTitle>Accounts Overview</CardTitle>
          <CardDescription>
            Your financial accounts distribution
          </CardDescription>
        </div>
        <Button size="sm" variant="outline">
          <PlusIcon className="h-4 w-4 mr-2" />
          Add Account
        </Button>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={mockAccountsData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                labelLine={false}
              >
                {mockAccountsData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value) => [`$${value.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, undefined]}
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--background))', 
                  border: '1px solid hsl(var(--border))' 
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 space-y-1">
          <div className="text-xs text-muted-foreground">Total Balance</div>
          <div className="text-2xl font-bold">
            ${totalBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="mt-2 grid grid-cols-3 gap-4">
            {mockAccountsData.map((account, index) => (
              <div key={index} className="flex flex-col">
                <div className="flex items-center">
                  <div className="mr-2 h-3 w-3 rounded-full" style={{ backgroundColor: account.color }} />
                  <span className="text-sm font-medium">{account.name}</span>
                </div>
                <span className="text-sm">
                  ${account.value.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}