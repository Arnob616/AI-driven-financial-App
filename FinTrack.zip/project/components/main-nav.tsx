'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { useSession } from 'next-auth/react';
import { BarChart3, CreditCard, Home, LineChart, PieChart, Wallet } from 'lucide-react';

export function MainNav() {
  const pathname = usePathname();
  const { status } = useSession();
  const isAuthenticated = status === 'authenticated';
  
  const isDashboardPage = pathname.includes('/dashboard');

  return (
    <div className="mr-4 flex">
      <Link href="/" className="mr-6 flex items-center space-x-2">
        <Wallet className="h-6 w-6" />
        <span className="hidden font-bold sm:inline-block">FinVue</span>
      </Link>
      <nav className="flex items-center space-x-6 text-sm font-medium">
        {isAuthenticated ? (
          <>
            <Link
              href="/dashboard"
              className={cn(
                "transition-colors hover:text-foreground/80",
                pathname === '/dashboard' ? "text-foreground" : "text-foreground/60"
              )}
            >
              <span className="flex items-center gap-1">
                <Home className="h-4 w-4" />
                <span className="hidden sm:inline">Dashboard</span>
              </span>
            </Link>
            <Link
              href="/dashboard/accounts"
              className={cn(
                "transition-colors hover:text-foreground/80",
                pathname.includes('/dashboard/accounts') ? "text-foreground" : "text-foreground/60"
              )}
            >
              <span className="flex items-center gap-1">
                <CreditCard className="h-4 w-4" />
                <span className="hidden sm:inline">Accounts</span>
              </span>
            </Link>
            <Link
              href="/dashboard/transactions"
              className={cn(
                "transition-colors hover:text-foreground/80",
                pathname.includes('/dashboard/transactions') ? "text-foreground" : "text-foreground/60"
              )}
            >
              <span className="flex items-center gap-1">
                <BarChart3 className="h-4 w-4" />
                <span className="hidden sm:inline">Transactions</span>
              </span>
            </Link>
            <Link
              href="/dashboard/insights"
              className={cn(
                "transition-colors hover:text-foreground/80",
                pathname.includes('/dashboard/insights') ? "text-foreground" : "text-foreground/60"
              )}
            >
              <span className="flex items-center gap-1">
                <PieChart className="h-4 w-4" />
                <span className="hidden sm:inline">Insights</span>
              </span>
            </Link>
          </>
        ) : (
          <>
            <Link
              href="/features"
              className={cn(
                "transition-colors hover:text-foreground/80",
                pathname === '/features' ? "text-foreground" : "text-foreground/60"
              )}
            >
              Features
            </Link>
            <Link
              href="/pricing"
              className={cn(
                "transition-colors hover:text-foreground/80",
                pathname === '/pricing' ? "text-foreground" : "text-foreground/60"
              )}
            >
              Pricing
            </Link>
            <Link
              href="/about"
              className={cn(
                "transition-colors hover:text-foreground/80",
                pathname === '/about' ? "text-foreground" : "text-foreground/60"
              )}
            >
              About
            </Link>
          </>
        )}
      </nav>
    </div>
  );
}