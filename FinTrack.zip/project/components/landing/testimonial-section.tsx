import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { QuoteIcon } from 'lucide-react';

export function TestimonialSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-muted px-3 py-1 text-sm">Testimonials</div>
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">
              Trusted by thousands of users
            </h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              See what our users have to say about how FinVue has transformed their financial management.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3 pt-12">
          <Card className="border shadow-sm">
            <CardContent className="p-6">
              <QuoteIcon className="h-8 w-8 text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">
                "FinVue has completely changed how I manage my money. The insights have helped me save an extra $500 each month!"
              </p>
            </CardContent>
            <CardFooter className="px-6 py-4 border-t flex items-center">
              <Avatar className="h-10 w-10 mr-3">
                <AvatarImage src="https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&dpr=2" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <div className="flex flex-col">
                <p className="text-sm font-medium">Jessica Davis</p>
                <p className="text-xs text-muted-foreground">Marketing Executive</p>
              </div>
            </CardFooter>
          </Card>
          <Card className="border shadow-sm">
            <CardContent className="p-6">
              <QuoteIcon className="h-8 w-8 text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">
                "The budget planning tools helped me pay off my student loans 2 years earlier than expected. Worth every penny!"
              </p>
            </CardContent>
            <CardFooter className="px-6 py-4 border-t flex items-center">
              <Avatar className="h-10 w-10 mr-3">
                <AvatarImage src="https://images.pexels.com/photos/3785083/pexels-photo-3785083.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&dpr=2" />
                <AvatarFallback>MJ</AvatarFallback>
              </Avatar>
              <div className="flex flex-col">
                <p className="text-sm font-medium">Michael Johnson</p>
                <p className="text-xs text-muted-foreground">Software Developer</p>
              </div>
            </CardFooter>
          </Card>
          <Card className="border shadow-sm">
            <CardContent className="p-6">
              <QuoteIcon className="h-8 w-8 text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">
                "The visualizations make it easy to understand where my money is going. I finally feel in control of my finances."
              </p>
            </CardContent>
            <CardFooter className="px-6 py-4 border-t flex items-center">
              <Avatar className="h-10 w-10 mr-3">
                <AvatarImage src="https://images.pexels.com/photos/3754261/pexels-photo-3754261.jpeg?auto=compress&cs=tinysrgb&w=60&h=60&dpr=2" />
                <AvatarFallback>SL</AvatarFallback>
              </Avatar>
              <div className="flex flex-col">
                <p className="text-sm font-medium">Sarah Liu</p>
                <p className="text-xs text-muted-foreground">Small Business Owner</p>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
    </section>
  );
}