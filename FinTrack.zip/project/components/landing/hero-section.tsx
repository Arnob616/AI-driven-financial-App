import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { ChevronRight } from 'lucide-react';

export function HeroSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-4 text-center">
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
              Take Control of Your Financial Future
            </h1>
            <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
              FinVue helps you track, manage, and understand your finances with powerful tools and insightful analytics.
            </p>
          </div>
          <div className="flex flex-col gap-2 min-[400px]:flex-row">
            <Button asChild size="lg" className="h-12">
              <Link href="/signup">
                Get Started
                <ChevronRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button variant="outline" size="lg" className="h-12" asChild>
              <Link href="/features">Learn More</Link>
            </Button>
          </div>
        </div>
      </div>
      <div className="container px-4 md:px-6 pt-12">
        <div className="relative mx-auto aspect-[16/9] overflow-hidden rounded-xl border bg-background shadow-xl md:w-full lg:w-10/12">
          <Image
            src="https://images.pexels.com/photos/7788009/pexels-photo-7788009.jpeg"
            alt="FinVue dashboard preview"
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-background/20" />
        </div>
      </div>
    </section>
  );
}