'use client';

import { useState } from 'react';
import { DashboardShell } from '@/components/dashboard/dashboard-shell';
import { DashboardHeader } from '@/components/dashboard/dashboard-header';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { 
  Plus, 
  Search,
  ArrowUpRight, 
  ArrowDownLeft, 
  MoreVertical,
  ChevronDown,
  FilterX,
  Download,
  Upload
} from 'lucide-react';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';

// Mock transaction data
const mockTransactions = [
  {
    id: '1',
    description: 'Starbucks',
    amount: 5.75,
    type: 'EXPENSE',
    category: 'Food',
    date: '2025-01-15T09:24:00',
    account: 'Chase Checking',
  },
  {
    id: '2',
    description: 'Amazon',
    amount: 49.99,
    type: 'EXPENSE',
    category: 'Shopping',
    date: '2025-01-14T17:31:00',
    account: 'Chase Credit Card',
  },
  {
    id: '3',
    description: 'Rent Payment',
    amount: 1200.00,
    type: 'EXPENSE',
    category: 'Housing',
    date: '2025-01-10T08:00:00',
    account: 'Chase Checking',
  },
  {
    id: '4',
    description: 'Paycheck',
    amount: 2100.00,
    type: 'INCOME',
    category: 'Salary',
    date: '2025-01-05T09:00:00',
    account: 'Chase Checking',
  },
  {
    id: '5',
    description: 'Uber',
    amount: 22.50,
    type: 'EXPENSE',
    category: 'Transportation',
    date: '2025-01-04T19:24:00',
    account: 'Amex Credit Card',
  },
  {
    id: '6',
    description: 'Chipotle',
    amount: 15.25,
    type: 'EXPENSE',
    category: 'Food',
    date: '2025-01-02T12:30:00',
    account: 'Chase Credit Card',
  },
  {
    id: '7',
    description: 'Side Project',
    amount: 350.00,
    type: 'INCOME',
    category: 'Freelance',
    date: '2024-12-28T15:45:00',
    account: 'Chase Checking',
  },
  {
    id: '8',
    description: 'Electric Bill',
    amount: 85.42,
    type: 'EXPENSE',
    category: 'Utilities',
    date: '2024-12-26T10:15:00',
    account: 'Chase Checking',
  },
  {
    id: '9',
    description: 'Grocery Store',
    amount: 132.57,
    type: 'EXPENSE',
    category: 'Groceries',
    date: '2024-12-24T14:20:00',
    account: 'Chase Credit Card',
  },
  {
    id: '10',
    description: 'Dividend Payment',
    amount: 37.50,
    type: 'INCOME',
    category: 'Investment',
    date: '2024-12-22T08:30:00',
    account: 'Fidelity Investments',
  },
];

export default function TransactionsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');
  
  const filteredTransactions = mockTransactions
    .filter(transaction => {
      if (selectedFilter === 'all') return true;
      if (selectedFilter === 'income') return transaction.type === 'INCOME';
      if (selectedFilter === 'expense') return transaction.type === 'EXPENSE';
      return true;
    })
    .filter(transaction => {
      if (!searchTerm) return true;
      return (
        transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.account.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });

  return (
    <DashboardShell>
      <DashboardHeader
        heading="Transactions"
        description="View and manage your financial transactions."
      >
        <Button size="sm">
          <Plus className="h-4 w-4 mr-2" />
          Add Transaction
        </Button>
      </DashboardHeader>
      
      <Card>
        <CardHeader className="flex-1">
          <div className="flex flex-col items-start justify-between space-y-2 lg:flex-row lg:items-center lg:space-y-0">
            <CardTitle>All Transactions</CardTitle>
            <div className="flex w-full items-center space-x-2 lg:w-auto">
              <div className="relative flex-1 lg:w-[300px]">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search transactions..."
                  className="w-full pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                  <button
                    className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground"
                    onClick={() => setSearchTerm('')}
                  >
                    <FilterX className="h-4 w-4" />
                  </button>
                )}
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="h-9">
                    <span>{selectedFilter === 'all' ? 'All Transactions' : selectedFilter === 'income' ? 'Income Only' : 'Expenses Only'}</span>
                    <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => setSelectedFilter('all')}>
                    All Transactions
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSelectedFilter('income')}>
                    Income Only
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSelectedFilter('expense')}>
                    Expenses Only
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <Button variant="outline" size="icon" className="h-9 w-9">
                <Download className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" className="h-9 w-9">
                <Upload className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="rounded-md border">
              <div className="relative w-full overflow-auto">
                <table className="w-full caption-bottom text-sm">
                  <thead>
                    <tr className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                      <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Date</th>
                      <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Description</th>
                      <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Category</th>
                      <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Account</th>
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">Amount</th>
                      <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {filteredTransactions.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="p-4 text-center text-muted-foreground">
                          No transactions found
                        </td>
                      </tr>
                    ) : (
                      filteredTransactions.map(transaction => (
                        <tr
                          key={transaction.id}
                          className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted"
                        >
                          <td className="p-4 align-middle">
                            {format(new Date(transaction.date), 'MMM d, yyyy')}
                          </td>
                          <td className="p-4 align-middle font-medium">
                            <div className="flex items-center">
                              <div className={`mr-2 flex h-6 w-6 items-center justify-center rounded-full ${
                                transaction.type === 'INCOME' 
                                  ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300'
                                  : 'bg-rose-100 text-rose-700 dark:bg-rose-900 dark:text-rose-300'
                              }`}>
                                {transaction.type === 'INCOME' 
                                  ? <ArrowUpRight className="h-3 w-3" />
                                  : <ArrowDownLeft className="h-3 w-3" />
                                }
                              </div>
                              {transaction.description}
                            </div>
                          </td>
                          <td className="p-4 align-middle">
                            <Badge variant="outline">
                              {transaction.category}
                            </Badge>
                          </td>
                          <td className="p-4 align-middle">
                            {transaction.account}
                          </td>
                          <td className={`p-4 align-middle text-right font-medium ${
                            transaction.type === 'INCOME' 
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-rose-600 dark:text-rose-400'
                          }`}>
                            {transaction.type === 'INCOME' ? '+' : '-'}
                            ${transaction.amount.toFixed(2)}
                          </td>
                          <td className="p-4 align-middle">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <MoreVertical className="h-4 w-4" />
                                  <span className="sr-only">Open menu</span>
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuItem>Edit</DropdownMenuItem>
                                <DropdownMenuItem>Categorize</DropdownMenuItem>
                                <DropdownMenuItem>Split Transaction</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-destructive">
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </DashboardShell>
  );
}