'use client';

import { useState } from 'react';
import { DashboardShell } from '@/components/dashboard/dashboard-shell';
import { DashboardHeader } from '@/components/dashboard/dashboard-header';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { PlusIcon, CreditCard, Wallet, LineChart, Landmark, ArrowDownUp } from 'lucide-react';

export default function AccountsPage() {
  const [activeTab, setActiveTab] = useState('all');

  // Mock account data - in a real app, this would come from your API
  const accounts = [
    {
      id: '1',
      name: 'Chase Checking',
      type: 'CHECKING',
      balance: 8540.23,
      currency: 'USD',
      lastUpdated: '2025-01-15T09:24:00',
      icon: <CreditCard className="h-5 w-5" />,
      color: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
    },
    {
      id: '2',
      name: 'Chase Savings',
      type: 'SAVINGS',
      balance: 12750.00,
      currency: 'USD',
      lastUpdated: '2025-01-15T09:24:00',
      icon: <Wallet className="h-5 w-5" />,
      color: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
    },
    {
      id: '3',
      name: 'Fidelity Investments',
      type: 'INVESTMENT',
      balance: 3290.30,
      currency: 'USD',
      lastUpdated: '2025-01-14T17:31:00',
      icon: <LineChart className="h-5 w-5" />,
      color: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
    },
    {
      id: '4',
      name: 'Amex Credit Card',
      type: 'CREDIT',
      balance: -1250.45,
      currency: 'USD',
      lastUpdated: '2025-01-15T09:24:00',
      icon: <CreditCard className="h-5 w-5" />,
      color: 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300',
    },
    {
      id: '5',
      name: 'Wells Fargo Loan',
      type: 'LOAN',
      balance: -15000.00,
      currency: 'USD',
      lastUpdated: '2025-01-10T08:00:00',
      icon: <Landmark className="h-5 w-5" />,
      color: 'bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300',
    },
  ];

  const filteredAccounts = activeTab === 'all' 
    ? accounts 
    : accounts.filter(a => a.type === activeTab.toUpperCase());

  return (
    <DashboardShell>
      <DashboardHeader
        heading="Accounts"
        description="Manage your financial accounts."
      >
        <Button size="sm">
          <PlusIcon className="h-4 w-4 mr-2" />
          Add Account
        </Button>
      </DashboardHeader>

      <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="checking">Checking</TabsTrigger>
          <TabsTrigger value="savings">Savings</TabsTrigger>
          <TabsTrigger value="credit">Credit</TabsTrigger>
          <TabsTrigger value="investment">Investment</TabsTrigger>
          <TabsTrigger value="loan">Loans</TabsTrigger>
        </TabsList>
        <TabsContent value={activeTab} className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredAccounts.map((account) => (
              <Card key={account.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-full ${account.color}`}>
                      {account.icon}
                    </div>
                    <Button variant="ghost" size="icon">
                      <ArrowDownUp className="h-4 w-4" />
                    </Button>
                  </div>
                  <CardTitle className="mt-2">{account.name}</CardTitle>
                  <CardDescription>
                    {account.type.charAt(0).toUpperCase() + account.type.slice(1).toLowerCase()} Account
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {account.balance < 0 ? '-' : ''}${Math.abs(account.balance).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Last updated {new Date(account.lastUpdated).toLocaleDateString()}
                  </p>
                </CardContent>
                <CardFooter className="bg-muted/50 pt-2">
                  <div className="flex justify-between w-full">
                    <Button variant="ghost" size="sm">View Transactions</Button>
                    <Button variant="ghost" size="sm">Edit</Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
            
            {/* Add Account Card */}
            <Card className="border-dashed flex flex-col items-center justify-center h-[200px] bg-muted/20">
              <CardContent className="flex flex-col items-center justify-center h-full p-6">
                <div className="rounded-full bg-primary/10 p-3 mb-4">
                  <PlusIcon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-xl mb-2">Add New Account</CardTitle>
                <CardDescription className="text-center mb-4">
                  Connect a bank account or add a manual account
                </CardDescription>
                <Button>Add Account</Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </DashboardShell>
  );
}