import { Suspense } from 'react';
import { DashboardShell } from '@/components/dashboard/dashboard-shell';
import { DashboardHeader } from '@/components/dashboard/dashboard-header';
import { OverviewStats } from '@/components/dashboard/overview-stats';
import { RecentTransactions } from '@/components/dashboard/recent-transactions';
import { AccountsOverview } from '@/components/dashboard/accounts-overview';
import { BudgetProgress } from '@/components/dashboard/budget-progress';
import { ExpensesChart } from '@/components/dashboard/expenses-chart';
import { SkeletonCard } from '@/components/ui/skeleton';

export default function DashboardPage() {
  return (
    <DashboardShell>
      <DashboardHeader
        heading="Dashboard"
        description="Get an overview of your financial status."
      />
      <div className="grid gap-4 md:gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
        <Suspense fallback={<SkeletonCard className="h-[120px]" />}>
          <OverviewStats />
        </Suspense>
      </div>
      <div className="grid gap-4 md:gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-7">
        <div className="col-span-1 md:col-span-2 lg:col-span-4">
          <Suspense fallback={<SkeletonCard className="h-[400px]" />}>
            <ExpensesChart />
          </Suspense>
        </div>
        <div className="col-span-1 md:col-span-2 lg:col-span-3">
          <Suspense fallback={<SkeletonCard className="h-[400px]" />}>
            <AccountsOverview />
          </Suspense>
        </div>
      </div>
      <div className="grid gap-4 md:gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-7">
        <div className="col-span-1 md:col-span-2 lg:col-span-3">
          <Suspense fallback={<SkeletonCard className="h-[300px]" />}>
            <BudgetProgress />
          </Suspense>
        </div>
        <div className="col-span-1 md:col-span-2 lg:col-span-4">
          <Suspense fallback={<SkeletonCard className="h-[300px]" />}>
            <RecentTransactions />
          </Suspense>
        </div>
      </div>
    </DashboardShell>
  );
}