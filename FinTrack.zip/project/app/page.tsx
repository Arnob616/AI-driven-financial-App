import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { HeroSection } from '@/components/landing/hero-section';
import { FeatureSection } from '@/components/landing/feature-section';
import { TestimonialSection } from '@/components/landing/testimonial-section';
import { PricingSection } from '@/components/landing/pricing-section';
import { CtaSection } from '@/components/landing/cta-section';
import { Footer } from '@/components/footer';

export default function Home() {
  return (
    <main className="flex flex-col items-center">
      <HeroSection />
      <FeatureSection />
      <TestimonialSection />
      <PricingSection />
      <CtaSection />
      <Footer />
    </main>
  );
}